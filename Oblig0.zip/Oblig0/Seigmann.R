df <- read.csv("./labanXY.csv")
print(df)